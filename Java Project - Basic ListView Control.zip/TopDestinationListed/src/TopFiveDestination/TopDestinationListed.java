package TopFiveDestination;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TopDestinationListed extends JFrame {
    private DefaultListModel<TextAndLink> listModel;

    public TopDestinationListed() {
        super("Top Five Destination List");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel<>();

        // Add destinations with links and images
        addDestinationNameAndPicture("1. China (Tour the Great Wall Of China)", "https://www.viator.com/tours/Beijing/Mutianyu-Great-Wall-Trip-with-English-Speaking-Driver/d321-7309P2", new ImageIcon(getClass().getResource("China.jpg")));
        addDestinationNameAndPicture("2. Japan (Visit the great Tokyo City)", "https://www.viator.com/tours/Tokyo/Tokyo-Explore-the-City-with-a-Local/d334-30791P157", new ImageIcon(getClass().getResource("Tokyo.jpg")));
        addDestinationNameAndPicture("3. South Korea (Learn South Korea culture)", "https://www.viator.com/tours/Seoul/Seoul-City-Sightseeing-Tour-Including-Gyeongbokgung-Palace-N-Seoul-Tower-and-Namsangol-Hanok-Village/d973-6780CITY_FULLDAY", new ImageIcon(getClass().getResource("South Korea.jpg")));
        addDestinationNameAndPicture("4. Thailand (Stay at a beautiful resort)", "https://www.viator.com/tours/Phuket/Phi-Phi-Island-Adventure-Day-Trip-by-Speedboat-from-Phuket-with-Lunch/d349-27424P2", new ImageIcon(getClass().getResource("Thailand.jpg")));
        addDestinationNameAndPicture("5. Vietnam (See the Wonders of Vietnam)", "https://www.viator.com/tours/Da-Nang/Ba-Na-Hills-with-Golden-Bridge-Private-Tour/d4680-129824P11", new ImageIcon(getClass().getResource("Vietnam.jpg")));

        JList<TextAndLink> list = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(list);
        JLabel nameLabel = new JLabel("Developer: Vimon");

        // Set the custom cell renderer
        TextAndLinkListCellRenderer renderer = new TextAndLinkListCellRenderer();
        list.setCellRenderer(renderer);

        // Add click listeners to open links
        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int index = list.locationToIndex(e.getPoint());
                if (index >= 0) {
                    TextAndLink item = listModel.getElementAt(index);
                    try {
                        Desktop.getDesktop().browse(new java.net.URI(item.getLink()));
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        // Add components to frame
        getContentPane().add(nameLabel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, String link, Icon icon) {
        TextAndLink tal = new TextAndLink(text, link, icon);
        listModel.addElement(tal);
    }

    // Entry point for the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TopDestinationListed frame = new TopDestinationListed();
            frame.setVisible(true);
        });
    }
}

// Helper class for holding text, link, and icon data
class TextAndLink {
    private final String text;
    private final String link;
    private final Icon icon;

    public TextAndLink(String text, String link, Icon icon) {
        this.text = text;
        this.link = link;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public String getLink() {
        return link;
    }

    public Icon getIcon() {
        return icon;
    }
}

// Custom renderer for list items
class TextAndLinkListCellRenderer extends JLabel implements ListCellRenderer<TextAndLink> {
    @Override
    public Component getListCellRendererComponent(JList<? extends TextAndLink> list, TextAndLink value, int index,
                                                  boolean isSelected, boolean cellHasFocus) {
        // Set text with an embedded link using HTML
        setText("<html><b>" + value.getText() + "</b><br><a href='" + value.getLink() + "'>" + value.getLink() + "</a></html>");
        setIcon(value.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        setOpaque(true);
        return this;
    }
}
